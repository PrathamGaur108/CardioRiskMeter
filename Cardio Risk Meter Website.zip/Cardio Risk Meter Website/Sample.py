from sklearn.metrics import adjusted_rand_score
from sklearn.utils import resample
import numpy as np

'''
Step 4: 
Preprocessing
'''

# Load the dataset
import pandas as pd
mcdonalds = pd.read_csv("mcdonalds.csv")

# Convert "Yes" and "No" to 1 and 0
mcdonalds.replace({"Yes": 1, "No": 0}, inplace=True)
# Standardization
X = mcdonalds.iloc[:, 0:11]
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Perform PCA
from sklearn.decomposition import PCA
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

# KMeans clustering
from sklearn.cluster import KMeans
kmeans = KMeans(n_clusters=4, random_state=1234)
kmeans.fit(X_scaled)
mcdonalds['kmeans_cluster'] = kmeans.labels_

# (Optional) Bootstrapping for K-means clustering
'''n_bootstraps = 100
boot_indices = resample(np.arange(len(MD_x)), n_samples=n_bootstraps, random_state=1234)
MD_b28 = [KMeans(n_clusters=i, random_state=1234).fit(MD_x[boot_indices]) for i in range(2, 9)]'''

# Gaussian Mixture Model clustering
from sklearn.mixture import GaussianMixture
gmm = GaussianMixture(n_components=4, random_state=1234)
gmm.fit(X_scaled)
mcdonalds['gmm_cluster'] = gmm.predict(X_scaled)

# Model fitting and evaluation
from sklearn.linear_model import LogisticRegression
logreg = LogisticRegression()
logreg.fit(X_scaled, mcdonalds['Like.n'])
from sklearn.tree import DecisionTreeClassifier
tree = DecisionTreeClassifier()
tree.fit(X_scaled, mcdonalds['Like.n'])

# (Optional) Hierarchical clustering
#MD_vclust = linkage(MD_x.T, method='complete')

# Visualization
import matplotlib.pyplot as plt
import seaborn as sns
plt.scatter(X_pca[:, 0], X_pca[:, 1], c=mcdonalds['kmeans_cluster'], cmap='viridis')
plt.xlabel('Principal Component 1')
plt.ylabel('Principal Component 2')
plt.show()
sns.barplot(x='kmeans_cluster', y='Like.n', data=mcdonalds)
sns.barplot(x='kmeans_cluster', y='Gender', data=mcdonalds)

# Decision tree visualization
plt.figure(figsize=(12, 8))
tree.plot_tree(filled=True, feature_names=X.columns, class_names=['Not Liked', 'Liked'])
plt.show()

# Cluster analysis
visit_mean = mcdonalds.groupby('kmeans_cluster')['VisitFrequency'].mean()
like_mean = mcdonalds.groupby('kmeans_cluster')['Like.n'].mean()
female_mean = mcdonalds.groupby('kmeans_cluster')['Gender'].apply(lambda x: (x == 'Female').mean())

plt.scatter(visit_mean, like_mean, s=10 * female_mean, alpha=0.5)
for i, txt in enumerate(range(1, 5)):
    plt.text(visit_mean[i], like_mean[i], txt)
plt.xlim(2, 4.5)
plt.ylim(-3, 3)
plt.show()





import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.cluster.hierarchy import dendrogram, linkage
from scipy.stats import chi2_contingency
from statsmodels.graphics.mosaicplot import mosaic
from statsmodels.formula.api import ols
from rpy2.robjects import pandas2ri
from rpy2.robjects.packages import importr
from rpy2.robjects import r, Formula
from rpy2.robjects.conversion import localconverter

# Load the dataset
mcdonalds = pd.read_csv("mcdonalds.csv")

# Preprocessing
mcdonalds['Like.n'] = 6 - mcdonalds['Like']
X = mcdonalds.iloc[:, 1:12]
y = mcdonalds['Like.n']

# PCA
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

# KMeans clustering
kmeans = KMeans(n_clusters=4, random_state=1234)
kmeans.fit(X_scaled)
k4 = kmeans.labels_

# Hierarchical clustering
linkage_matrix = linkage(X_scaled.T, method='ward')
dendrogram(linkage_matrix, labels=X.columns, leaf_rotation=90)

# Visualization
plt.scatter(X_pca[:, 0], X_pca[:, 1], c=k4, cmap='viridis')
plt.xlabel('Principal Component 1')
plt.ylabel('Principal Component 2')
plt.show()

# Mosaic plot
mosaic(pd.crosstab(k4, mcdonalds['Like']), title='Like by segment number')
mosaic(pd.crosstab(k4, mcdonalds['Gender']), title='Gender by segment number')

# Regression tree
formula = 'factor(k4 == 3) ~ Like.n + Age + VisitFrequency + Gender'
with localconverter(pandas2ri.converter) as cv:
    formula_r = Formula(formula)
    mcdonalds_r = pandas2ri.py2ri(mcdonalds)
    tree = r['ctree'](formula_r, data=mcdonalds_r)
r['plot'](tree)

# Analysis
visit_mean = mcdonalds.groupby(k4)['VisitFrequency'].mean()
like_mean = mcdonalds.groupby(k4)['Like.n'].mean()
female_mean = mcdonalds.groupby(k4)['Gender'].apply(lambda x: (x == 'Female').mean())

plt.scatter(visit_mean, like_mean, s=10 * female_mean, alpha=0.5)
for i, txt in enumerate(range(1, 5)):
    plt.text(visit_mean[i], like_mean[i], txt)
plt.xlim(2, 4.5)
plt.ylim(-3, 3)
plt.show()





import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import LabelEncoder
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.metrics import adjusted_rand_score
from sklearn.utils import resample
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
mcdonalds = pd.read_csv("mcdonalds.csv")

# Display column names and dimensions of the dataset
print(mcdonalds.columns)
print(mcdonalds.shape)

# Display the first 3 rows of the dataset
print(mcdonalds.head(3))

# Preprocess the data
md_x = mcdonalds.iloc[:, 1:12].apply(lambda x: LabelEncoder().fit_transform(x))
md_x = md_x.values

# Perform PCA
pca = PCA()
md_pca = pca.fit_transform(md_x)
print(pca.explained_variance_ratio_)

# Perform KMeans clustering
kmeans = KMeans(n_clusters=4, random_state=1234)
md_k4 = kmeans.fit_predict(md_x)

# Perform Gaussian Mixture Model clustering
gmm = GaussianMixture(n_components=4, random_state=1234)
md_m4 = gmm.fit_predict(md_x)

# Evaluate clustering results
print(adjusted_rand_score(md_k4, md_m4))

# Perform logistic regression
logreg = LogisticRegression(random_state=1234)
logreg.fit(md_x, md_k4)

# Visualize the clustering results
sns.scatterplot(x=md_pca[:, 0], y=md_pca[:, 1], hue=md_k4, palette="Set2")
plt.show()

# Visualize the decision boundary
sns.scatterplot(x=md_pca[:, 0], y=md_pca[:, 1], hue=md_k4, palette="Set2")
plt.show()

# Visualize the cluster centroids
sns.scatterplot(x=md_pca[:, 0], y=md_pca[:, 1], hue=md_k4, palette="Set2")
plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], c='black', marker='x', s=200)
plt.show()

# Perform decision tree classification
dt = DecisionTreeClassifier(random_state=1234)
dt.fit(md_x, md_k4)

# Visualize the decision tree
plt.figure(figsize=(10, 10))
tree.plot_tree(dt, filled=True, feature_names=mcdonalds.columns[1:12], class_names=["0", "1", "2", "3"])
plt.show()

# Analyze cluster characteristics
cluster_means = mcdonalds.groupby(md_k4).mean()
print(cluster_means)
