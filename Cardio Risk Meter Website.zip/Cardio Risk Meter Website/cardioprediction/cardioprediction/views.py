from django.shortcuts import render
import joblib
#from .models import MLModel

def index(request):
    return render(request, "index.html")

def aboutus(request):
    return render(request, "AboutUs.html")

def prediction(request):
    return render(request, "Prediction.html")

def predicted(request):
    if request.method == "POST":
        age = int(request.POST.get("age"))
        gender = int(request.POST.get("gender"))
        chestpain = int(request.POST.get("chestpain"))
        restingbp = int(request.POST.get("restingbp"))
        serumcholestrol = int(request.POST.get("serumcholestrol"))
        fastingbs = int(request.POST.get("fastingbs"))
        restingrelectro = int(request.POST.get("restingrelectro"))
        maxheartrate = int(request.POST.get("maxheartrate"))
        exerciseangia = int(request.POST.get("exerciseangia"))
        oldpeak = int(request.POST.get("oldpeak"))
        slope = int(request.POST.get("slope"))
        majvessels = int(request.POST.get("noofmajvessels"))
        classifier = joblib.load('finalized_model.sav')
        result = int(classifier.predict([[age, gender, chestpain, restingbp, serumcholestrol, fastingbs, restingrelectro, maxheartrate, exerciseangia, oldpeak, slope, majvessels]]))
        data = {}
        data['age'] = age
        data['gender'] = gender
        data['chestpain'] = chestpain
        data['restingbp'] = restingbp
        data['serumcholestrol'] = serumcholestrol
        data['fastingbs'] = fastingbs
        data['restingrelectro'] = restingrelectro
        data['maxheartrate'] = maxheartrate
        data['exerciseangia'] = exerciseangia
        data['oldpeak'] = oldpeak
        data['slope'] = slope
        data['majvessels'] = majvessels
        if result == 1:
            data['result'] = "You may have Cardiovascular Disease. Consult to Doctor."
        else:
            data["result"] = "You may not have Cardiovascular Disease. Stay Healthy!"
        return render(request, "Predicted.html", data)